package com.mycompany.codigo_java_dougals;

public class Sistema {
    private int id;
    private String nome = "admin";
    
    public Sistema(){}

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }
    
    public void cadastroCliente(Cliente cliente){
        
    }
    
    public void cadastroTreinador(Funcionario funcionario){
        
    }
    
    public void modificarTreinador(Funcionario funcionario){
        
    }
    
}
