package com.mycompany.codigo_java_dougals;

public class Treino {
    private int id;
    private String nome;
    private String musculoAfetado;
    private int series;
    
    public Treino(String nome, String musculoAfetado, int series){
        this.nome = nome;
        this.musculoAfetado = musculoAfetado;
        this.series = series;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getMusculoAfetado() {
        return musculoAfetado;
    }

    public void setMusculoAfetado(String musculoAfetado) {
        this.musculoAfetado = musculoAfetado;
    }

    public int getSeries() {
        return series;
    }

    public void setSeries(int series) {
        this.series = series;
    }

    @Override
    public String toString() {
        return super.toString();
    }
    
    
}
