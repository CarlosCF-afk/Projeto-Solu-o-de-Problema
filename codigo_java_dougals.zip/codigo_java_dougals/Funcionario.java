package com.mycompany.codigo_java_dougals;

public class Funcionario extends Usuario {
    private int id;
    private String funcao;
    private Cliente[] cartelaClientes;
    
    public Funcionario(String nome, String nasc, String cpf, String endereco, String telefone){
        super(nome, nasc, cpf, endereco, telefone);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFuncao() {
        return funcao;
    }

    public void setFuncao(String funcao) {
        this.funcao = funcao;
    }

    public Cliente[] getCartelaClientes() {
        return cartelaClientes;
    }

    public void setCartelaClientes(Cliente[] cartelaClientes) {
        this.cartelaClientes = cartelaClientes;
    }
    
    public void criarTreino(){
        
    }
    
    public void modificarTreino(Treino treino){
        
    }
    
    public void atualizarCadastro(Cliente cliente){
        
    }
}
