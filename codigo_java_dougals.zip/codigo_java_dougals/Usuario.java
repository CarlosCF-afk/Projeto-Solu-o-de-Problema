package com.mycompany.codigo_java_dougals;

public class Usuario {
    private String nome;
    private String nasc;
    private String cpf;
    private String endereco;
    private String telefone;
    
    
    public Usuario(String nome, String nasc, String cpf, String endereco, String telefone) {
        
        this.nome = nome;
        this.nasc = nasc;
        this.cpf = cpf;
        this.endereco = endereco;
        this.telefone = telefone;
        
    }
    
    

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getNome(){
        return nome;
    }

    public void setNasc(String nasc){
        this.nasc = nasc;
    }

    public String getNasc(){
        return nasc;
    }

    public void setCpf(String cpf){
        this.cpf = cpf;
    }

    public String getCpf(){
        return cpf;
    }

    public void setEndereco(String endereco){
        this.endereco = endereco;
    }

    public String getEndereco(){
        return endereco;
    }

    public void setTelefone(String telefone){
        this.telefone = telefone;
    }

    public String getTelefone(){
        return telefone;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    
    
}
