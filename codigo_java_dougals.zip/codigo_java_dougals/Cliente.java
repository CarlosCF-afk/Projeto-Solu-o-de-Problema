package com.mycompany.codigo_java_dougals;

public class Cliente extends Usuario {
    private int id;
    private Treino[] treinos;
    
    public Cliente(String nome, String nasc, String cpf, String endereco, String telefone){
        super(nome, nasc, cpf, endereco, telefone);
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Treino[] getTreinos() {
        return treinos;
    }

    public void setTreinos(Treino[] treinos) {
        this.treinos = treinos;
    }
    
    public void acessarTreino(Treino treino){
        
    }
    
    public void acessarCadastro(Cliente cliente){
        
    }
    
    public void modificarTreino(Treino treino){
        
    }
    
    public void agendarTreino(Treino treino){
        
    }
    
}
